# 项目记录与脚本接口

项目资料写入用户工作目录，与 Skill 安装目录分开。只需要一个 `project.json` 保存索引、研究配置和质检状态；大量原始数据、论文正文、分析程序、访谈记录、文献全文另存文件并在索引引用。小任务只登记本次使用的部分，不强制建立空台账。

## 核心结构

下列键名是 `scripts/audit_project.py` 的输入协议。ID 在项目内稳定，修改章节或文献显示编号时不改 ID。日期使用 ISO 8601。未核验字段使用 null 或空值，并登记任务；空值不代表通过。

```json
{
  "schema_version": 2,
  "project": {
    "title": "研究题目",
    "mode": "proposal_to_thesis",
    "thesis_type": "topic_research",
    "stage": "research_draft",
    "citation_style": "numeric",
    "citation_standard": "GB/T 7714-2025",
    "standard_verification": {"number": "GB/T 7714-2025", "status": "current", "effective_on": "2026-07-01", "checked_on": "2026-09-09", "official_url": "本项目实际核验的官方页面URL"},
    "research_period": "实际研究期间",
    "template": "所用模板路径与版本",
    "delivery_variant": "working"
  },
  "proposal_baseline": {},
  "changes": [],
  "research_questions": [],
  "sources": [],
  "claims": [],
  "data_items": [],
  "displays": [],
  "tasks": [],
  "qa": {}
}
```

## 条目字段

- `proposal_baseline`：保存题目、对象、问题、目标、主理论、核心方法、技术路线、主体目录、预期成果、原开题文件和定位。无开题时为空。
- `project.mode` 为 topic_to_thesis / proposal_to_thesis / thesis_revision / finalization；`thesis_type` 为 topic_research / case_descriptive / case_problem / other（other另存培养单位认可依据type_authority）。`delivery_variant` 为 working / review / archive。`standard_verification` 每项目启动与定稿真实核验后填写，示例日期不照抄；脚本只查记录一致性，不联网判断“最新”。
- `changes[]`：`id, before, after, reason, impact, substantive, authorization, status`。status为proposed / approved / implemented / declined；substantive为布尔。`authorization` 记录用户原话所在回合/文件或既有授权范围；日常编辑不必逐句登记。
- `research_questions[]`：`id, question, unit, inference_goal, method, evidence_ids, chapters, output, status`。`evidence_ids` 指向 sources 或 data_items；`status` 为 planned / in_progress / answered。`output` 说明拟形成的成果；answered另填`answer`（由分析形成的实际答案）和`answer_location`（章/节、段落锚点或图表后的论证位置）。可加`answer_claim_ids`连接claims；填写时已回答问题所关联的论断需为supported，实际语义对应在审读中核对。
- `sources[]`：`id, kind, title, publisher, origin, accessed_on, access_scope, verification, eligibility, locator, qualification, used_in_bibliography, bibliography_key`。`kind` 为 official / academic / third_party / internal / auxiliary；`origin` 为正规原始 URL 或用户本地材料路径；`locator` 为实际页码/表号/段落/记录定位；题录另加 authors/year/container/doi 等真实字段。
- `access_scope` 为 metadata_only / abstract / full_text / dataset；`verification` 为 verified / unverified；`eligibility` 为 accepted / reference_only / rejected。这些是不同维度，不把“第三方已交叉验证”另造一个与 accepted 重叠的状态。
- `qualification`：第三方必需，包含 `traceable_origin, period, population, definition, method, research_fit`。每项写实际说明，不能只填 true。原始机构单独发布的官方数据无需伪造第二出处；交叉核验另记 `corroboration`（独立原始来源 ID、差异和处理结论）。
- `claims[]`：`id, text, kind, evidence_ids, locator, section, status, reviewer_note`。`kind` 为 factual / interpretation / proposal / scenario；`status` 为 supported / pending / withdrawn。解释和建议也应写依据与边界。`locator` 是证据的具体内容定位；实际语义支撑由研究者复核，脚本只查结构。
- `data_items[]`：`id, indicator, value, unit, period, definition, population, source_ids, status`；衍生量另加 `input_ids, formula, analysis_path`；`status` 为 observed / calculated / scenario / pending。`value` 可为有限数值、非空文本或待取得时的null，不能用布尔、NaN或Infinity；情景值不得标observed。pending条目可连接待核验候选来源，脚本提示但不将其视为已验证事实。
- `displays[]`：`id, kind, number, title, research_question_id, data_ids, source_ids, first_mention, note, calculation_checked, format_checked`；可加`status`为planned / included，省略或null按included检查；未采用图表须明确标planned。`kind`为table / figure；编号如`3.1`或附录`A.1`，与稳定ID分开。planned为研究计划，可暂缺实际数据和正文首次引用；纳入正文后必须有合格证据。两个checked字段用真实布尔值，不用字符串“true”；完全没有数值核验的定性表/图可将calculation_checked设为not_applicable，并用calculation_note说明原因。图表关联数值或派生数据时应完成相应转录/计算复核，不能以not_applicable跳过；脚本沿数据依赖检查明确数值和calculated记录，字符串形式的数值及表内实际内容仍需审读。
- `tasks[]`：`id, need, purpose, owner, status, blocking`；任务状态为 open / done / waived；waived另存reason。只有具体理由和可接受替代路径才能 waived，不能把尚未取得的研究结果标完成。
- 补充材料与修订任务可增加`draft_locations, required_inputs, replacement_rule, acceptance_criteria`及受影响ID，按 [独立补充说明](delivery-contract.md#正文与独立说明)整理给用户。位置优先用章/节、段落首句和表图编号，页码随稿件版本更新；正文不需要保留任务占位语。这些扩展字段用于记录，当前脚本不校验它们的完整性。
- [二轮完善](delivery-contract.md#补充资料后的二轮完善)沿用已有任务ID和状态。材料已核验、相关分析已更新、正文及关联位置已整合、受影响检查通过后才标`done`，在处理记录写明材料、分析文件、新位置与复核依据；仅收到资料不关闭任务。部分补料先处理已满足的部分，其余任务保持`open`。
- `qa`：`evidence_semantics, calculations, citations, repetition, academic_style, consistency, docx_structure, visual_pages`。每项为 `{status: pass|pending|not_applicable, evidence: 实际审查记录路径或说明}`。`visual_pages` 另记 rendered_file、checked_pages、total_pages。另记录外部查重报告的来源、日期、覆盖范围；没有报告就不填写查重率。

## 状态只描述已经完成的工作

新项目采用schema_version=2，标answered时须有实际答案及正文定位。旧schema_version=1继续可读；缺少答案记录时给出具体补录提示，不用计划成果名称代替答案。依据现有正文补录后可将版本改为2，其他字段及稳定ID保持原值。小任务只记录实际涉及的研究问题。

`research_draft` 允许存在待取数据；`research_ready` 表示关键研究路径与现有证据可执行；`full_draft` 表示全篇正文完成，但审计可能未完成；`review_ready` 表示可供导师审阅；`submission_candidate` 需全部相关质量检查完成、关键资料任务关闭、目标版本明确。脚本不会代替导师、学校或正式查重系统作出送审决定。

数据更正后用稳定 ID 找到关联的论断、图表、章节、摘要和结论，只重做受影响的分析与检查。跨会话继续时先读项目记录与未完成任务，避免重新选题。

## 修改稿与质检版本

先写工作稿、后补真实数据时，可设`project.contains_temporary_results=true`，按 [临时结果工作稿](questionnaire-and-simulation.md#临时结果与真实数据更新)管理替换。字段可省略以兼容旧项目，填写时必须为布尔值；true在草稿中为警告，在submission_candidate中为错误。脚本不自动扫描正文来推断该字段，设false需有实际替换和复核依据。

多轮修改时可增加 `project.content_revision`，写本项目稳定的正文/数据快照标识，如 `draft-03`；它与技能的软件版本分别管理。各项QA另加 `reviewed_revision`，记录该检查实际覆盖的内容版本。

启用内容版本记录后，送审候选稿要求所有QA与当前 `content_revision` 一致。修改数字、分析、章节或排版后，把受影响QA改为pending并重查；未受影响的检查可以在比对后沿用，在evidence说明未受影响的范围及比较依据，再登记当前版本。新增字段是可选的，旧项目不被要求伪造历史记录；只填版本字符串也不能代替审查。

视觉QA应记录实际输入DOCX、渲染PDF或页面文件，以及核验日期。完整论文任务按 [Word定稿与逐页验收](word-and-tables.md#全文定稿与逐页验收)登记文件哈希；环境无法计算时明确缺失，不能伪造。可在相关QA项中增加 `input_file, input_sha256, rendered_sha256, checked_on`，沿用 `rendered_file` 与实际页码；这些是记录字段，项目审计不验证其外部文件内容。内容变动可能导致后续页码、目录和表格分页连锁变化，需重新渲染后确认影响范围。引用、结构和文本重复检查脚本自动记录所读输入的哈希，但不证明已完成视觉审查，也不替用户重置QA。

## 检查范围

脚本检查已回答问题、已支持论断及已纳入图表的证据状态，沿衍生数据回查来源；证据ID存在不等于可用。accepted来源的accessed_on应为不晚于当前日期的真实ISO日期。送审候选至少应有真实已支持的论断，不能用全部withdrawn代替研究结果。参考文献键应唯一；用于实质论断、研究问题或已纳入图表的公开证据（official、academic、third_party、auxiliary）在送审候选稿中与文后登记对应，内部访谈/业务材料按实际资料标识和适用附录管理。文后条目应有研究中的实质使用位置；正文实际引用字符、题录各字段和现行国标细节仍需结合论文人工检查。

`standard_verification.official_url`指向国家市场监督管理总局体系的实际官方标准记录（如std.samr.gov.cn或openstd.samr.gov.cn）；脚本只校验域名/日期/版本记录一致性，实时状态要实际打开核对。草稿阶段可只记录本次需要的内容，待核验来源与研究任务不被冒充正式证据，也不因此阻止不受影响的写作。
